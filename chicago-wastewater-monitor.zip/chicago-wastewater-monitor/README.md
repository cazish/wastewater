# Chicago Wastewater Monitor

A zero-cost-friendly GitHub Actions project that checks Chicago's respiratory-virus wastewater dataset every day, keeps a rolling history, publishes a static dashboard through GitHub Pages, emails only when a new reporting week changes a signal, and flags newly discovered Chicago wastewater datasets for review.

## What it monitors

- Citywide SARS-CoV-2, influenza A, influenza B, and RSV records from Chicago dataset `4tzt-ir6h`.
- Activity category, viral activity value, concentration, and reporting week.
- Chicago's Socrata catalog for newly published wastewater or sewage datasets.
- This does **not** infer infection counts or drinking-water safety, and it does not label a newly found dataset as bacterial surveillance until its fields are reviewed.

## Deploy in GitHub

1. Create a new GitHub repository and upload the contents of this folder, including the hidden `.github` directory.
2. In **Settings → Actions → General → Workflow permissions**, enable **Read and write permissions**.
3. In **Settings → Pages**, choose **GitHub Actions** as the source.
4. Add the email settings below under **Settings → Secrets and variables → Actions → New repository secret**.
5. Open **Actions → Daily Chicago wastewater check → Run workflow** once. The dashboard is deployed after the run.
6. Open **Settings → Pages** to find the dashboard URL. The page file is `chicago-wastewater-monitor.html`.

The schedule is 8:17 AM America/Chicago daily. Minute 17 avoids the busiest top-of-hour period. Edit `.github/workflows/daily-check.yml` to change it.

## Email secrets

| Secret | Example / purpose |
|---|---|
| `SMTP_HOST` | `smtp.gmail.com` |
| `SMTP_PORT` | `465` |
| `SMTP_USER` | Sending email address |
| `SMTP_PASSWORD` | SMTP password; for Gmail, use an app password rather than the normal account password |
| `EMAIL_FROM` | Optional sender address; normally same as `SMTP_USER` |
| `EMAIL_TO` | Recipient address; comma-separated addresses are not supported in this version |

If email secrets are omitted, data collection and the dashboard still work; the action log states that email was skipped. Secrets remain in GitHub Actions rather than in committed files.

## Notification logic

An email is sent when a new source week appears and any concentration changes, when an activity category changes, when a new pathogen appears, or when the catalog reveals a new Chicago wastewater dataset. The first run establishes a baseline and does not send email. To test first-run email, add `EMAIL_ON_FIRST_RUN: "true"` to the workflow step's environment.

## Local test

```bash
python monitor.py
python -m http.server 8000 --directory docs
```

Then open `http://localhost:8000/chicago-wastewater-monitor.html`. Run `node --check docs/app.js` to syntax-check the dashboard JavaScript.

## Files

- `monitor.py` — API retrieval, comparison, catalog discovery, history, and SMTP notification.
- `.github/workflows/daily-check.yml` — daily cloud schedule and GitHub Pages deployment.
- `docs/chicago-wastewater-monitor.html` — responsive dashboard.
- `docs/data/latest.json` and `history.json` — generated data used by the dashboard.
- `monitor_state.json` — prior values used to detect changes.

## Operational notes

Scheduled GitHub Actions run from the default branch and can occasionally be delayed during high load. The workflow also supports a manual run. The monitor fails visibly if Chicago's API is unavailable rather than replacing real observations with estimated data.
