const categoryClass = value => `level-${String(value).toLowerCase().replaceAll(' ', '-')}`;
const fmt = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });
const state = { latest: null, history: [] };

function themeController() {
  const button = document.querySelector('[data-theme-toggle]');
  let mode = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  const apply = () => {
    document.documentElement.dataset.theme = mode;
    button.setAttribute('aria-label', `Switch to ${mode === 'dark' ? 'light' : 'dark'} mode`);
    button.innerHTML = mode === 'dark' ? '☀ Light' : '◐ Dark';
  };
  button.addEventListener('click', () => { mode = mode === 'dark' ? 'light' : 'dark'; apply(); });
  apply();
}

function renderCards(records) {
  const grid = document.querySelector('#cards');
  grid.innerHTML = records.map(record => `
    <article class="metric-card">
      <div class="metric-top"><h2>${record.pathogen}</h2><span class="badge ${categoryClass(record.activity_category)}">${record.activity_category}</span></div>
      <p class="metric-number">${fmt.format(record.concentration)}</p>
      <p class="muted">Average concentration · activity value ${record.activity_value.toFixed(1)}</p>
      <p class="date">Week ending ${record.week_end}</p>
    </article>`).join('');
}

function renderTable(records) {
  document.querySelector('#rows').innerHTML = records.map(record => `
    <tr><th scope="row">${record.pathogen}</th><td><span class="dot ${categoryClass(record.activity_category)}"></span>${record.activity_category}</td><td>${record.activity_value.toFixed(1)}</td><td>${fmt.format(record.concentration)}</td><td>${record.week_end}</td></tr>`).join('');
}

function drawChart(history, pathogen) {
  const canvas = document.querySelector('#trend-chart');
  const ctx = canvas.getContext('2d');
  const points = history.filter(row => row.pathogen === pathogen).slice(-16);
  const dpr = devicePixelRatio || 1;
  const width = canvas.clientWidth, height = canvas.clientHeight;
  canvas.width = width * dpr; canvas.height = height * dpr; ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, width, height);
  if (!points.length) return;
  const pad = { l: 52, r: 16, t: 16, b: 36 };
  const plotW = width - pad.l - pad.r, plotH = height - pad.t - pad.b;
  const values = points.map(p => Number(p.concentration));
  const max = Math.max(...values, 1);
  const style = getComputedStyle(document.documentElement);
  const muted = style.getPropertyValue('--color-text-muted');
  const divider = style.getPropertyValue('--color-divider');
  const primary = style.getPropertyValue('--color-primary');
  ctx.font = '12px Satoshi, sans-serif'; ctx.fillStyle = muted; ctx.strokeStyle = divider; ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = pad.t + plotH * i / 4;
    ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(width - pad.r, y); ctx.stroke();
    ctx.fillText(fmt.format(max * (4 - i) / 4), 4, y + 4);
  }
  ctx.strokeStyle = primary; ctx.lineWidth = 3; ctx.lineJoin = 'round'; ctx.beginPath();
  points.forEach((p, i) => {
    const x = pad.l + (points.length === 1 ? plotW / 2 : plotW * i / (points.length - 1));
    const y = pad.t + plotH * (1 - Number(p.concentration) / max);
    i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
  });
  ctx.stroke();
  ctx.fillStyle = muted;
  const labels = [0, Math.floor((points.length - 1) / 2), points.length - 1];
  [...new Set(labels)].forEach(i => {
    const x = pad.l + (points.length === 1 ? plotW / 2 : plotW * i / (points.length - 1));
    ctx.fillText(points[i].week_end.slice(5), Math.min(x - 16, width - 50), height - 10);
  });
}

function renderDatasets(datasets) {
  const tbody = document.querySelector('#dataset-rows');
  tbody.innerHTML = datasets.map(d => `<tr><th scope="row">${d.name}</th><td><code>${d.id}</code></td><td>${d.updated_at ? new Date(d.updated_at).toLocaleDateString() : '—'}</td><td><a href="${d.url}" target="_blank" rel="noopener noreferrer">Open dataset</a></td></tr>`).join('');
}

async function loadData() {
  try {
    const [latestResponse, historyResponse] = await Promise.all([fetch('./data/latest.json'), fetch('./data/history.json')]);
    if (!latestResponse.ok || !historyResponse.ok) throw new Error('Data files could not be loaded');
    state.latest = await latestResponse.json(); state.history = await historyResponse.json();
    renderCards(state.latest.records); renderTable(state.latest.records); renderDatasets(state.latest.discovered_datasets);
    const select = document.querySelector('#pathogen');
    select.innerHTML = state.latest.records.map(r => `<option>${r.pathogen}</option>`).join('');
    select.addEventListener('change', () => drawChart(state.history, select.value));
    document.querySelector('#checked').textContent = new Date(state.latest.checked_at).toLocaleString();
    document.querySelector('#sample-week').textContent = state.latest.latest_sample_week_end;
    drawChart(state.history, select.value);
  } catch (error) {
    document.querySelector('#status').innerHTML = `<div class="error-state"><strong>Dashboard data unavailable.</strong><span>${error.message}. Run the workflow once to populate the data.</span></div>`;
  }
}

addEventListener('resize', () => state.latest && drawChart(state.history, document.querySelector('#pathogen').value));
document.querySelector('#download').addEventListener('click', () => location.href = './data/history.csv');
themeController(); loadData();
