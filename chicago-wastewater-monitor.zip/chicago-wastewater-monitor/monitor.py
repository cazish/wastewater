#!/usr/bin/env python3
import csv, json, os, smtplib, ssl, sys
from datetime import datetime, timezone
from email.message import EmailMessage
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "docs" / "data"
STATE_FILE = ROOT / "monitor_state.json"
API = "https://data.cityofchicago.org/resource/4tzt-ir6h.json"
CATALOG = "https://api.us.socrata.com/api/catalog/v1"
SOURCE = "https://data.cityofchicago.org/Health-Human-Services/Respiratory-Virus-Wastewater-Surveillance/4tzt-ir6h"
RANK = {"Minimal": 0, "Low": 1, "Moderate": 2, "High": 3, "Very High": 4}


def get_json(url, params=None):
    if params:
        url += ("&" if "?" in url else "?") + urlencode(params)
    req = Request(url, headers={"User-Agent": "ChicagoWastewaterMonitor/1.0", "Accept": "application/json"})
    with urlopen(req, timeout=45) as response:
        return json.load(response)


def load_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def fetch_latest():
    rows = get_json(API, {
        "$where": "lower(sitename)='all sites'",
        "$order": "week_end DESC,pathogen ASC",
        "$limit": "80",
    })
    if not rows:
        raise RuntimeError("Chicago API returned no citywide records")
    latest_week = max(row["week_end"] for row in rows)
    current = []
    for row in rows:
        if row.get("week_end") != latest_week:
            continue
        current.append({
            "pathogen": row.get("pathogen", "Unknown"),
            "week_start": row.get("week_start", "")[:10],
            "week_end": row.get("week_end", "")[:10],
            "concentration": float(row.get("target_wkavg_concentration") or 0),
            "activity_value": float(row.get("wkavg_val") or 0),
            "activity_category": row.get("wkavg_val_category", "Unavailable"),
            "site": row.get("sitename", "All sites"),
        })
    return sorted(current, key=lambda x: x["pathogen"]), rows


def discover_datasets():
    found = {}
    for query in ("wastewater", "sewage surveillance", "wastewater pathogen"):
        payload = get_json(CATALOG, {"search_context": "data.cityofchicago.org", "q": query, "limit": "100"})
        for item in payload.get("results", []):
            resource = item.get("resource", {})
            dataset_id = resource.get("id")
            name = resource.get("name", "")
            description = resource.get("description", "")
            text = f"{name} {description}".lower()
            if dataset_id and ("wastewater" in text or "sewage" in text):
                found[dataset_id] = {
                    "id": dataset_id,
                    "name": name,
                    "description": description[:400],
                    "updated_at": resource.get("updatedAt", ""),
                    "url": item.get("permalink", f"https://data.cityofchicago.org/d/{dataset_id}"),
                }
    return sorted(found.values(), key=lambda x: (x["name"].lower(), x["id"]))


def compact_snapshot(records):
    return {r["pathogen"]: {"category": r["activity_category"], "value": r["activity_value"], "concentration": r["concentration"], "week_end": r["week_end"]} for r in records}


def compare(previous, current, old_ids, new_ids):
    changes = []
    for pathogen, now in current.items():
        before = previous.get(pathogen)
        if before is None:
            changes.append(f"New pathogen: {pathogen} ({now['category']})")
        elif before.get("week_end") != now.get("week_end"):
            old_category = before.get("category", "Unavailable")
            if old_category != now["category"]:
                changes.append(f"{pathogen}: {old_category} → {now['category']}")
            elif abs(float(before.get("concentration", 0)) - now["concentration"]) > 0:
                direction = "increased" if now["concentration"] > float(before.get("concentration", 0)) else "decreased"
                changes.append(f"{pathogen}: concentration {direction}; category remains {now['category']}")
    for dataset_id in sorted(new_ids - old_ids):
        changes.append(f"New Chicago wastewater dataset discovered: {dataset_id}")
    return changes


def write_outputs(records, api_rows, datasets, checked_at):
    DATA.mkdir(parents=True, exist_ok=True)
    payload = {
        "checked_at": checked_at,
        "latest_sample_week_end": records[0]["week_end"],
        "source_url": SOURCE,
        "records": records,
        "discovered_datasets": datasets,
        "note": "Activity categories are community-level wastewater signals, not case counts.",
    }
    (DATA / "latest.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    history_path = DATA / "history.json"
    history = load_json(history_path, [])
    by_key = {(r.get("week_end"), r.get("pathogen")): r for r in history}
    for row in api_rows:
        if row.get("sitename", "").lower() != "all sites":
            continue
        item = {
            "week_end": row.get("week_end", "")[:10],
            "pathogen": row.get("pathogen", "Unknown"),
            "concentration": float(row.get("target_wkavg_concentration") or 0),
            "activity_value": float(row.get("wkavg_val") or 0),
            "activity_category": row.get("wkavg_val_category", "Unavailable"),
        }
        by_key[(item["week_end"], item["pathogen"])] = item
    history = sorted(by_key.values(), key=lambda r: (r["week_end"], r["pathogen"]))[-416:]
    history_path.write_text(json.dumps(history, indent=2) + "\n", encoding="utf-8")

    with (DATA / "history.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["week_end", "pathogen", "concentration", "activity_value", "activity_category"])
        writer.writeheader(); writer.writerows(history)


def send_email(records, changes, checked_at):
    required = ["SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD", "EMAIL_TO"]
    missing = [name for name in required if not os.getenv(name)]
    if missing:
        print("Email skipped; missing secrets: " + ", ".join(missing))
        return
    host = os.environ["SMTP_HOST"]
    port = int(os.getenv("SMTP_PORT", "465"))
    sender = os.getenv("EMAIL_FROM", os.environ["SMTP_USER"])
    lines = ["Chicago wastewater monitor detected an update.", "", *[f"• {c}" for c in changes], "", "Latest citywide activity:"]
    lines.extend(f"• {r['pathogen']}: {r['activity_category']} (week ending {r['week_end']})" for r in records)
    lines.extend(["", f"Checked: {checked_at}", f"Source: {SOURCE}"])
    msg = EmailMessage()
    msg["Subject"] = "Chicago wastewater update"
    msg["From"] = sender
    msg["To"] = os.environ["EMAIL_TO"]
    msg.set_content("\n".join(lines))
    context = ssl.create_default_context()
    if port == 465:
        with smtplib.SMTP_SSL(host, port, context=context, timeout=45) as smtp:
            smtp.login(os.environ["SMTP_USER"], os.environ["SMTP_PASSWORD"]); smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=45) as smtp:
            smtp.starttls(context=context); smtp.login(os.environ["SMTP_USER"], os.environ["SMTP_PASSWORD"]); smtp.send_message(msg)


def main():
    checked_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    old_state = load_json(STATE_FILE, {})
    records, api_rows = fetch_latest()
    datasets = discover_datasets()
    current = compact_snapshot(records)
    old_ids = set(old_state.get("dataset_ids", []))
    new_ids = {d["id"] for d in datasets}
    changes = compare(old_state.get("snapshot", {}), current, old_ids, new_ids)
    write_outputs(records, api_rows, datasets, checked_at)
    STATE_FILE.write_text(json.dumps({"checked_at": checked_at, "snapshot": current, "dataset_ids": sorted(new_ids)}, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"checked_at": checked_at, "changes": changes, "records": records}, indent=2))
    if changes and (old_state or os.getenv("EMAIL_ON_FIRST_RUN", "false").lower() == "true"):
        send_email(records, changes, checked_at)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise
